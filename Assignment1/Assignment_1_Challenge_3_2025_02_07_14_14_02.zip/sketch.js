function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  //first row
  stroke(10000)
  fill(25,30,40)
  rect(1,0, 80,80)
 fill(184,134,11)
rect(81,0, 80,80)
  rect(160,0, 80,80)
   fill(25,30,40)
  rect(240,0, 80,80)
 fill(184,134,11)
  rect(320,0, 80,80)
  //second row
  fill(25,30,40)
    rect(1,80, 80,80)
  fill(218,165,32)
  rect(81,80, 80,80)
  fill(25,30,40)
  rect(160,80, 80,80)
   fill(184,134,11)
  rect(240,80, 80,80)
   fill(218,165,32)
  rect(320,80, 80,80)
  //third row
  fill(25,30,40)
   rect(1,160, 80,80)
  fill(25,30,40)
  rect(81,160, 80,80)
  fill(255,215,0)
  rect(160,160, 80,80)
  rect(240,160, 80,80)
  rect(320,160, 80,80)
  //fourth row
 fill(25,30,40)
  rect(1,240, 80,80)
  fill	(255,255,0)
  rect(81,240, 80,80)
  fill(25,30,40)
  rect(160,240, 80,80)
   fill(255,215,0)
  rect(240,240, 80,80)
  fill	(255,255,0)
  rect(320,240, 80,80)
  //fifth row
  fill(25,30,40)
  rect(1,320, 80,80)
 fill(255,255,0)
  rect(81,320, 80,80)
  rect(160,320, 80,80)
   fill(25,30,40)
  rect(240,320, 80,80)
     fill(255,255,0)
  rect(320,320, 80,80)
  
}